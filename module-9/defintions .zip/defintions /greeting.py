def greeting():
    print("Hello There")

def author(name):
    print('{}: {}'.format("Author",name))
