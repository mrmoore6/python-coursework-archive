def print_set(set):
    for i in set:
        print(i)
