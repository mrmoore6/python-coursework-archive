def print_dict(dict):
    for key,values in dict.items():
        print(key,values)
